package controller

import (
	"book_ease_go/middleware"
	"book_ease_go/model"
	response "book_ease_go/responses"
	"fmt"

	"github.com/gofiber/fiber/v2"
)

//Data Analytics
//Overall Registered Users "Student
func CountStudents(c *fiber.Ctx) error {
	var count int64

	// Count the number of users with user_type = "Student"
	if err := middleware.DBConn.Debug().
		Table("users").
		Where("user_type = ?", "Student").
		Count(&count).Error; err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to count students",
			Data:    err.Error(),
		})
	}

	// Return the count of students
	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Student count fetched successfully",
		Data:    count,
	})
}



// Add or Register a Book
func AddBook(c *fiber.Ctx) error {
    var book model.Book
    if err := c.BodyParser(&book); err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "Invalid request format"})
    }

    // Check if book already exists
    var existingBook model.Book
    if err := middleware.DBConn.Debug().Table("books").Where("title = ?", book.Title).First(&existingBook).Error; err == nil {
        return c.JSON(response.ResponseModel{
            RetCode: "400",
            Message: "Book already exists",
            Data:    nil,
        })
    }

    // Insert the book into the database
    if err := middleware.DBConn.Debug().Table("books").Create(&book).Error; err != nil {
        fmt.Println("Error inserting book:", err) // Log the error
        return c.JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to Add Book",
            Data:    err.Error(),
        })
    }

    return c.JSON(response.ResponseModel{
        RetCode: "200",
        Message: "Book Added Successfully",
        Data:    book,
    })
}

// Update Details of the book
func UpdateBook(c *fiber.Ctx) error {
	var book model.Book

	// Parse the request body to get updated book details
	if err := c.BodyParser(&book); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request format",
		})
	}

	// Check if the book exists based on book_id
	var existingBook model.Book
	if err := middleware.DBConn.Table("books").Where("book_id = ?", book.BookID).First(&existingBook).Error; err != nil {
		// Return an error if the book is not found
		if err.Error() == "record not found" {
			return c.JSON(response.ResponseModel{
				RetCode: "404",
				Message: "Book not found",
				Data:    nil,
			})
		}
		// Return other database errors
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to fetch book",
			Data:    err.Error(),
		})
	}

	// Update the fields of the existing book
	// You can update only the fields that have been changed, keeping it efficient
	if err := middleware.DBConn.Table("books").Where("book_id = ?", book.BookID).Updates(model.Book{
		Title:           book.Title,
		Author:          book.Author,
		Category:        book.Category,
		ISBN:            book.ISBN,
		LibrarySection:  book.LibrarySection,
		ShelfLocation:   book.ShelfLocation,
		TotalCopies:     book.TotalCopies,
		AvailableCopies: book.AvailableCopies,
		BookCondition:   book.BookCondition,
		Picture:         book.Picture,
	}).Error; err != nil {
		// Log and return the error
		fmt.Printf("Error updating book: %v\n", err)
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to update book",
			Data:    err.Error(),
		})
	}

	// Return success response
	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Book updated successfully",
		Data:    book,
	})
}

// Get Students
func GetUsers(c *fiber.Ctx) error {
    var users []model.User

    // Fetch only users with user_type = "Student"
    if err := middleware.DBConn.Debug().
        Table("users").
        Where("user_type = ?", "Student").
        Find(&users).Error; err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to fetch users",
            Data:    err.Error(),
        })
    }

    // Format the user data
    var formattedUsers []map[string]interface{}
    for _, user := range users {
        // Handle optional fields inline
        middleName := ""
        if user.MiddleName != nil {
            middleName = *user.MiddleName
        }

        suffix := ""
        if user.Suffix != nil {
            suffix = *user.Suffix
        }

        yearLevel := ""
        if user.YearLevel != nil {
            yearLevel = *user.YearLevel
        }

        program := ""
        if user.Program != nil {
            program = *user.Program
        }

        // Build full name with clean formatting
        fullName := fmt.Sprintf("%s, %s", user.LastName, user.FirstName)
        if middleName != "" {
            fullName += " " + middleName
        }
        if suffix != "" {
            fullName += " " + suffix
        }

        formattedUsers = append(formattedUsers, map[string]interface{}{
            "user_id":    user.UserID,
            "name":       fullName,
            "year_level": yearLevel,
            "program":    program,
        })
    }

    return c.JSON(response.ResponseModel{
        RetCode: "200",
        Message: "Users fetched successfully",
        Data:    formattedUsers,
    })
}

