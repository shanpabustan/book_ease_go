package controller

import (
	"book_ease_go/middleware"
	"book_ease_go/model"
	response "book_ease_go/responses"
	"fmt"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
)

//Data Analytics
//Overall Registered Users "Student
func CountStudents(c *fiber.Ctx) error {
	var count int64

	// Count the number of users with user_type = "Student"
	if err := middleware.DBConn.Debug().
		Table("users").
		Where("user_type = ?", "Student").
		Count(&count).Error; err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to count students",
			Data:    err.Error(),
		})
	}

	// Return the count of students
	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Student count fetched successfully",
		Data:    count,
	})
}



// Add or Register a Book
func AddBook(c *fiber.Ctx) error {
	var book model.Book

	// Parse body
	if err := c.BodyParser(&book); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request format",
		})
	}

	// Check if the book already exists by title or ISBN
	var existingBook model.Book
	if err := middleware.DBConn.
		Table("books").
		Where("title = ? OR isbn = ?", book.Title, book.ISBN).
		First(&existingBook).Error; err == nil {
		return c.Status(fiber.StatusConflict).JSON(response.ResponseModel{
			RetCode: "400",
			Message: "Book already exists",
			Data:    nil,
		})
	}

	// Auto-set AvailableCopies to match TotalCopies
	book.AvailableCopies = book.TotalCopies

	// Save to DB
	if err := middleware.DBConn.Create(&book).Error; err != nil {
		fmt.Println("Error inserting book:", err)
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to add book",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Book added successfully",
		Data:    book,
	})
}



// Update Details of the book
func UpdateBook(c *fiber.Ctx) error {
	var book model.Book

	// Parse the request body to get updated book details
	if err := c.BodyParser(&book); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request format",
		})
	}

	// Check if the book exists based on book_id
	var existingBook model.Book
	if err := middleware.DBConn.Table("books").Where("book_id = ?", book.BookID).First(&existingBook).Error; err != nil {
		// Return an error if the book is not found
		if err.Error() == "record not found" {
			return c.JSON(response.ResponseModel{
				RetCode: "404",
				Message: "Book not found",
				Data:    nil,
			})
		}
		// Return other database errors
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to fetch book",
			Data:    err.Error(),
		})
	}

	// Update the fields of the existing book
	// You can update only the fields that have been changed, keeping it efficient
	if err := middleware.DBConn.Table("books").Where("book_id = ?", book.BookID).Updates(model.Book{
		Title:           book.Title,
		Author:          book.Author,
		Category:        book.Category,
		ISBN:            book.ISBN,
		LibrarySection:  book.LibrarySection,
		ShelfLocation:   book.ShelfLocation,
		TotalCopies:     book.TotalCopies,
		AvailableCopies: book.AvailableCopies,
		BookCondition:   book.BookCondition,
		Picture:         book.Picture,
	}).Error; err != nil {
		// Log and return the error
		fmt.Printf("Error updating book: %v\n", err)
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to update book",
			Data:    err.Error(),
		})
	}

	// Return success response
	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Book updated successfully",
		Data:    book,
	})
}


// Get Students
func GetUsers(c *fiber.Ctx) error {
    var users []model.User

    // Fetch only users with user_type = "Student"
    if err := middleware.DBConn.Debug().
        Table("users").
        Where("user_type = ?", "Student").
        Find(&users).Error; err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to fetch users",
            Data:    err.Error(),
        })
    }

    // Format the user data
    var formattedUsers []map[string]interface{}
    for _, user := range users {
        // Handle optional fields inline
        middleName := ""
        if user.MiddleName != nil {
            middleName = *user.MiddleName
        }

        suffix := ""
        if user.Suffix != nil {
            suffix = *user.Suffix
        }

        yearLevel := ""
        if user.YearLevel != nil {
            yearLevel = *user.YearLevel
        }

        program := ""
        if user.Program != nil {
            program = *user.Program
        }

        // Build full name with clean formatting
        fullName := fmt.Sprintf("%s, %s", user.LastName, user.FirstName)
        if middleName != "" {
            fullName += " " + middleName
        }
        if suffix != "" {
            fullName += " " + suffix
        }

        formattedUsers = append(formattedUsers, map[string]interface{}{
            "user_id":    user.UserID,
            "name":       fullName,
            "email":     user.Email,  
            "program":    program,     
            "year_level": yearLevel,
            "contact_number": user.ContactNumber,
            
        })
    }

    return c.JSON(response.ResponseModel{
        RetCode: "200",
        Message: "Users fetched successfully",
        Data:    formattedUsers,
    })
}


//Disable Student Accounts
func DisableAllStudents(c *fiber.Ctx) error {
	result := middleware.DBConn.
		Model(&model.User{}).
		Where("user_type = ? AND is_active = ?", "Student", true).
		Update("is_active", false)

	if result.Error != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to disable students",
			Data:    result.Error.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: fmt.Sprintf("Successfully disabled %d students", result.RowsAffected),
		Data:    nil,
	})
}

// Admin - Approve reservation and create borrowed book record
func ApproveReservation(c *fiber.Ctx) error {
    reservationIDStr := c.Params("reservation_id")
    reservationID, err := strconv.Atoi(reservationIDStr)
    if err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
            RetCode: "400",
            Message: "Invalid reservation ID",
            Data:    err.Error(),
        })
    }

    var reservation model.Reservation
    if err := middleware.DBConn.First(&reservation, "reservation_id = ?", reservationID).Error; err != nil {
        return c.Status(fiber.StatusNotFound).JSON(response.ResponseModel{
            RetCode: "404",
            Message: "Reservation not found",
            Data:    nil,
        })
    }

    // Check if the reservation is in "Pending" status
    if reservation.Status != "Pending" {
        return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
            RetCode: "400",
            Message: "Only pending reservations can be approved",
            Data:    nil,
        })
    }

    // Start a transaction
    tx := middleware.DBConn.Begin()
    defer func() {
        if r := recover(); r != nil {
            tx.Rollback()
        }
    }()

    // Decrease available copies first
    var book model.Book
    if err := tx.First(&book, reservation.BookID).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Book not found",
            Data:    err.Error(),
        })
    }

    // Ensure the available copies are greater than 0 before approving the reservation
    if book.AvailableCopies <= 0 {
        tx.Rollback()
        return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
            RetCode: "400",
            Message: "No available copies for this book",
            Data:    nil,
        })
    }

    // Decrease available copies and total copies if necessary
    book.AvailableCopies--
    if err := tx.Save(&book).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to update book availability",
            Data:    err.Error(),
        })
    }

    // Approve reservation
    reservation.Status = "Approved"
    if err := tx.Save(&reservation).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to approve reservation",
            Data:    err.Error(),
        })
    }

    // Create borrowed book record
    borrowed := model.BorrowedBook{
        ReservationID:       reservation.ReservationID,
        UserID:              reservation.UserID,
        BookID:              reservation.BookID,
        BorrowDate:          time.Now(),
        DueDate:             time.Now().AddDate(0, 0, 7), // Due in 7 days
        Status:              "Approved",
        BookConditionBefore: book.BookCondition,
    }

    if err := tx.Create(&borrowed).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Reservation approved, but failed to create borrowed book entry",
            Data:    err.Error(),
        })
    }

    // Commit the transaction
    if err := tx.Commit().Error; err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to commit transaction",
            Data:    err.Error(),
        })
    }

    return c.JSON(response.ResponseModel{
        RetCode: "200",
        Message: "Reservation approved and book borrowed successfully",
        Data:    borrowed,
    })
}


// Admin - Cancel reservation
func DisapproveReservation(c *fiber.Ctx) error {
	reservationID := c.Params("reservation_id")

	var reservation model.Reservation
	if err := middleware.DBConn.First(&reservation, "reservation_id = ?", reservationID).Error; err != nil {
		return c.Status(fiber.StatusNotFound).JSON(response.ResponseModel{
			RetCode: "404",
			Message: "Reservation not found",
			Data:    nil,
		})
	}

	if reservation.Status != "Pending" {
		return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
			RetCode: "400",
			Message: "Only pending reservations can be disapproved",
			Data:    nil,
		})
	}

	reservation.Status = "Cancelled"
	if err := middleware.DBConn.Save(&reservation).Error; err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to disapprove reservation",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Reservation disapproved successfully",
		Data:    reservation,
	})
}


func ReturnBook(c *fiber.Ctx) error {
    borrowedIDStr := c.Params("borrowed_id")
    borrowedID, err := strconv.Atoi(borrowedIDStr)
    if err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
            RetCode: "400",
            Message: "Invalid borrowed book ID",
            Data:    err.Error(),
        })
    }

    // Start a transaction
    tx := middleware.DBConn.Begin()
    defer func() {
        if r := recover(); r != nil {
            tx.Rollback()
        }
    }()

    // Retrieve the borrowed book record
    var borrowed model.BorrowedBook
    if err := tx.First(&borrowed, "borrow_id = ?", borrowedID).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusNotFound).JSON(response.ResponseModel{
            RetCode: "404",
            Message: "Borrowed book record not found",
            Data:    nil,
        })
    }

    // Check if the book is already returned
    if borrowed.Status == "Returned" {
        tx.Rollback()
        return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
            RetCode: "400",
            Message: "This book has already been returned",
            Data:    nil,
        })
    }

    // Retrieve the corresponding book record
    var book model.Book
    if err := tx.First(&book, borrowed.BookID).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Book not found",
            Data:    err.Error(),
        })
    }

    // Increase available copies
    book.AvailableCopies++
    if err := tx.Save(&book).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to update book availability",
            Data:    err.Error(),
        })
    }

    // Mark the borrowed book as returned
    borrowed.Status = "Returned"
    if err := tx.Save(&borrowed).Error; err != nil {
        tx.Rollback()
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to update borrowed book status",
            Data:    err.Error(),
        })
    }

    // Commit the transaction
    if err := tx.Commit().Error; err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
            RetCode: "500",
            Message: "Failed to commit transaction",
            Data:    err.Error(),
        })
    }

    return c.JSON(response.ResponseModel{
        RetCode: "200",
        Message: "Book returned successfully, and availability updated",
        Data:    borrowed,
    })
}



