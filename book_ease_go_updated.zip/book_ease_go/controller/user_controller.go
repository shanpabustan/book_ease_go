package controller

import (
	"book_ease_go/middleware"
	"book_ease_go/model"
	response "book_ease_go/responses"
	"errors"
	"fmt"
	"mime/multipart"

	//"strings"

	"time"

	"github.com/gofiber/fiber/v2"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// Register User
func CreateStudent(c *fiber.Ctx) error {
	var student model.User

	// Parse JSON body
	if err := c.BodyParser(&student); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"RetCode": "400",
			"Message": "Invalid request data",
			"Error":   err.Error(),
		})
	}

	// ✅ Check if user_id already exists
	var existingUser model.User
	err := middleware.DBConn.Table("users").Where("user_id = ?", student.UserID).First(&existingUser).Error

	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		fmt.Println("DB Query Error:", err)
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"RetCode": "500",
			"Message": "Database Error",
			"Error":   err.Error(),
		})
	}

	// If user exists, return error
	if err == nil {
		fmt.Println("User already exists:", student.UserID)
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"RetCode": "400",
			"Message": "User already exists",
		})
	}

	// ✅ Force user_type to "Student"
	student.UserType = "Student"
	student.Picture = nil

	// ✅ Hash the password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(student.Password), bcrypt.DefaultCost)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"RetCode": "500",
			"Message": "Failed to hash password",
			"Error":   err.Error(),
		})
	}
	
	student.Password = string(hashedPassword)


	// ✅ Insert new user
	if err := middleware.DBConn.Table("users").Create(&student).Error; err != nil {
		fmt.Println("DB Insert Error:", err)
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"RetCode": "500",
			"Message": "Failed to Create User",
			"Error":   err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"RetCode": "201",
		"Message": "Registration Successful",
		"Data":    student,
	})
}

// Login function
func LoginUser(c *fiber.Ctx) error {
	var input model.User

	// Parse request body
	if err := c.BodyParser(&input); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(response.ResponseModel{
			RetCode: "400",
			Message: "Invalid request body",
			Data:    err.Error(),
		})
	}

	// Find user by user_id
	var users model.User
	if err := middleware.DBConn.Table("users").Where("user_id = ?", input.UserID).First(&users).Error; err != nil {
		// Check for record not found error
		if err.Error() == "record not found" {
			return c.Status(fiber.StatusUnauthorized).JSON(response.ResponseModel{
				RetCode: "401",
				Message: "Invalid user ID or password",
			})
		}
		return c.Status(fiber.StatusInternalServerError).JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Server error",
			Data:    err.Error(),
		})
	}

	// Compare hashed password
	if err := bcrypt.CompareHashAndPassword([]byte(users.Password), []byte(input.Password)); err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(response.ResponseModel{
			RetCode: "401",
			Message: "Invalid user ID or password",
		})
	}

	// Set redirect URL based on user type from the database
	var redirectURL string
	switch users.UserType { // Now using users.UserType from the database
	case "Admin":
		redirectURL = "/admin/dashboard"
	case "Student":
		redirectURL = "/student/dashboard"
	default:
		return c.Status(fiber.StatusUnauthorized).JSON(response.ResponseModel{
			RetCode: "401",
			Message: "Unauthorized user type",
		})
	}

	// Return success response
	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Login successful",
		Data: fiber.Map{
			"user_id":      users.UserID,
			"user_type":    users.UserType,
			"last_name":    users.LastName,
			"first_name":   users.FirstName,
			"middle_name":  users.MiddleName,
			"suffix":       users.Suffix,
			"email":        users.Email,
			"program":      users.Program,
			"year_level":   users.YearLevel,
			"contact_number": users.ContactNumber,
			"picture": func() interface{} {
						if users.Picture != nil {
							return users.Picture
						}
						return nil
					}(),
			"redirect_url": redirectURL,
		},
	})
}


// EditUser updates a user's personal information
func EditUser(c *fiber.Ctx) error {
	var request struct {
		UserID     string `json:"user_id"`
		FirstName  string `json:"first_name"`
		LastName   string `json:"last_name"`
		MiddleName string `json:"middle_name"`
		Suffix     string `json:"suffix"`
		ContactNumber string `json:"contact_number"`
		Program       string `json:"program"`
		YearLevel     string `json:"year_level"`
	}

	// Parse JSON request body
	if err := c.BodyParser(&request); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"RetCode": "400",
			"Message": "Invalid request payload",
			"Error":   err.Error(),
		})
	}

	// Find user by ID
	var user model.User
	if err := middleware.DBConn.Table("users").Where("user_id = ?", request.UserID).First(&user).Error; err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"RetCode": "404",
			"Message": "User not found",
		})
	}

	// Update user fields
	user.FirstName = request.FirstName
	user.LastName = request.LastName
	user.MiddleName = &request.MiddleName
	user.Suffix = &request.Suffix
	user.ContactNumber = &request.ContactNumber
	user.Program = &request.Program
	user.YearLevel = &request.YearLevel

	// Save changes
	if err := middleware.DBConn.Table("users").Save(&user).Error; err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"RetCode": "500",
			"Message": "Failed to update user",
			"Error":   err.Error(),
		})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"RetCode": "200",
		"Message": "User updated successfully",
		"Data":    user,
	})
}

func UploadPicture(c *fiber.Ctx) error {
    // Get user_id from request
    userID := c.FormValue("user_id")
    if userID == "" {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
            "RetCode": "400",
            "Message": "User ID is required",
        })
    }

    // Get uploaded file
    file, err := c.FormFile("picture")
    if err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
            "RetCode": "400",
            "Message": "Invalid file upload",
            "Error":   err.Error(),
        })
    }

    // Check if the file is an image (optional)
    if !isValidImage(file) {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
            "RetCode": "400",
            "Message": "Invalid file type. Only image files are allowed.",
        })
    }

    // Open file
    fileData, err := file.Open()
    if err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
            "RetCode": "500",
            "Message": "Failed to process file",
            "Error":   err.Error(),
        })
    }
    defer fileData.Close()

    // Read file content into a byte slice
    imageBytes := make([]byte, file.Size)
    _, err = fileData.Read(imageBytes)
    if err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
            "RetCode": "500",
            "Message": "Failed to read file",
            "Error":   err.Error(),
        })
    }

    // Log that the image is being uploaded
    fmt.Println("Uploading profile picture for user:", userID)

    // Update user's profile picture in PostgreSQL (BYTEA column)
    if err := middleware.DBConn.Table("users").
        Where("user_id = ?", userID).
        Update("picture", imageBytes).Error; err != nil {
        return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
            "RetCode": "500",
            "Message": "Failed to save profile picture",
            "Error":   err.Error(),
        })
    }

    // Return success response
    return c.Status(fiber.StatusOK).JSON(fiber.Map{
        "RetCode": "200",
        "Message": "Profile picture uploaded successfully",
    })
}

// Function to check if the file is a valid image (optional)
func isValidImage(file *multipart.FileHeader) bool {
	// Perform basic file type checking here (you can enhance this)
	contentType := file.Header.Get("Content-Type")
	return contentType == "image/jpeg" || contentType == "image/png"
}




//Book Reservation
func ReserveBook(c *fiber.Ctx) error {
	var reservation model.Reservation
	if err := c.BodyParser(&reservation); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"message": err.Error(),
		})
	}

	// unique id for reservation
	reservation.ReservationID = uint(time.Now().UnixNano())

	// checking of reservation
	var existingReservation model.Reservation
	if err := middleware.DBConn.Debug().Table("reservations").Where("reservation_id = ?", reservation.ReservationID).First(&existingReservation).Error; err == nil {
		return c.JSON(response.ResponseModel{
			RetCode: "400",
			Message: "Reservation already exists",
			Data:    nil,
		})
	}

	if err := middleware.DBConn.Debug().Table("reservations").Create(&reservation).Error; err != nil {
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to Create",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Reservation Successful",
		Data:    reservation,
	})
}

//FETCHING SECTION

// will base on the most borrowed books by the users
func FetchRecommendedBooks(c *fiber.Ctx) error {
	userID := c.Query("user_id")

	var books []model.Book
	bookfetch := middleware.DBConn.Debug().Table("books").
		Where("is_recommended = ? AND user_id = ?", true, userID)

	if err := bookfetch.Find(&books).Error; err != nil {
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to Fetch Recommended Books",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Recommended Books Fetched Successfully",
		Data:    books,
	})
}

//fetch borrowed books
func FetchBorrowedBooks(c *fiber.Ctx) error {
	userID := c.Query("user_id")
	if userID == "" {
		return c.JSON(response.ResponseModel{
			RetCode: "400",
			Message: "User ID is required",
			Data:    nil,
		})
	}

	var books []model.Book
	bookfetch := middleware.DBConn.Debug().Table("books").
		Joins("JOIN reservations ON books.book_id = reservations.book_id").
		Where("reservations.user_id = ? AND reservations.status = ?", userID, "Approved")

	if err := bookfetch.Find(&books).Error; err != nil {
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to Fetch Borrowed Books",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "Borrowed Books Fetched Successfully",
		Data:    books,
	})
}


func FetchAllBooks(c *fiber.Ctx) error {
	var books []model.Book
	bookfetch := middleware.DBConn.Debug().Table("books")

	if err := bookfetch.Find(&books).Error; err != nil {
		return c.JSON(response.ResponseModel{
			RetCode: "500",
			Message: "Failed to Fetch All Books",
			Data:    err.Error(),
		})
	}

	return c.JSON(response.ResponseModel{
		RetCode: "200",
		Message: "All Books Fetched Successfully",
		Data:    books,
	})
}




